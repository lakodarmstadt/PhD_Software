Detailed documentation of functions
===================================


.. toctree::
   :maxdepth: 2
   
   alkali_atom_functions
   alkali_atom_data
   calculations_atoms_single
   calculations_atom_pairstate
